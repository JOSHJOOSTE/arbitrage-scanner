# JJ's Arbitrage

This is your public arbitrage scanner site.

## Hosting on GitHub Pages

1. Go to https://github.com and log in as **JOSHJOOSTE**.
2. Click **New Repository** → name it `arbitrage-scanner` → Public → Create.
3. Click **Upload files** and drag **all files** from this folder into GitHub.
4. Commit changes.
5. Go to **Settings → Pages**.
6. Under "Branch", select `main` and `/ (root)` → Save.
7. Your site will be live at:
   https://joshjooste.github.io/arbitrage-scanner/

